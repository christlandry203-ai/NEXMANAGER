# NEXMANAGER by NEXCODE

Gestionnaire de fichiers Android (Kotlin + Jetpack Compose). minSdk 24, targetSdk 34.

## Compiler
1. Installer Android Studio (Koala ou plus récent, JDK 17 inclus).
2. File > Open > dossier NEXMANAGER, attendre la synchronisation Gradle.
3. Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk
   (ou en ligne de commande : ./gradlew assembleDebug ; si gradlew est absent : gradle wrapper --gradle-version 8.7)
4. Release signée : Build > Generate Signed App Bundle / APK.

## Logo
Remplacer app/src/main/res/drawable/ic_nexcode_logo.xml (ou ajouter un PNG du même nom) par le vrai logo NEXCODE.

## Transfert (v1.1)
- Appui long = sélection multiple ; Copier / Déplacer / Supprimer ; « Coller ici » avec confirmation et barre de progression.
- Onglet Transfert : stockage interne, carte SD, clé USB/OTG (détectés via StorageManager), choix d'un dossier via SAF.
- Applications installées : export de l'APK (Téléchargements/NEXMANAGER) ou partage ; jamais de données privées.

## Version 1.1.0 : transfert amélioré
- Écran Transfert : étapes guidées, liste des éléments avec taille totale, choix Copier/Déplacer, destinations rapides, espace utilisé par emplacement, « Coller dans le dossier actuel », derniers transferts.
- Fenêtre de progression : pourcentage, barre dégradée, élément en cours (n sur N), vitesse, temps restant, destination, annulation.
- Fin de transfert : résumé (éléments, taille, durée, vitesse moyenne) ou erreur claire avec bouton « Réessayer ».
- Fichiers : « Tout sélectionner », taille totale affichée dans la barre de collage et dans la confirmation.

## Version 1.1.1 : catégories
- Accueil : Images, Vidéos, Musique et Documents affichent directement TOUS les fichiers du type choisi (via l'index média d'Android, avec analyse du stockage en secours), au lieu d'ouvrir un dossier.
- Dans une catégorie : « Voir le dossier » pour ouvrir le dossier d'un fichier, tri par nom/taille/date, sélection multiple, copie, déplacement, suppression.
- Téléchargements ouvre toujours le dossier Download.

## Version 1.2.0 : grands écrans et PC (Chromebook, tablette, Android sur PC)
- Écran large (≥ 720 dp de large sur un appareil ≥ 600 dp) : barre de navigation latérale à la place de celle du bas, contenu centré.
- Fichiers : panneau de gauche (emplacements, accès rapide, catégories), fil d'Ariane cliquable, panneau de détails à droite (≥ 1000 dp).
- Souris : survol, clic = sélectionner, double-clic = ouvrir, clic droit = menu.
- Clavier : Entrée ouvrir, Suppr supprimer, F2 renommer, F5 actualiser, Retour arrière dossier parent, Échap désélectionner, Ctrl+A / Ctrl+C / Ctrl+X / Ctrl+V.
- Sur téléphone, l'interface ne change pas.
- Installable sur appareils sans écran tactile (uses-feature touchscreen non requis) ; fenêtre redimensionnable.
- Ce n'est PAS une application Windows (.exe) : voir la feuille de route (Compose Desktop).

## Mises à jour installables par-dessus (signature stable)
Les APK de debug compilés par GitHub étaient signés avec une clé différente à chaque compilation, ce qui faisait refuser la mise à jour par Android (« conflit avec un paquet existant »). Le projet contient maintenant `app/debug.keystore` (clé de DEBUG publique, mot de passe « android », sans valeur secrète) : toutes les compilations suivantes ont la même signature et s'installent par-dessus. Première fois : désinstaller l'ancienne version une seule fois.
