# NEXMANAGER by NEXCODE

Gestionnaire de fichiers Android (Kotlin + Jetpack Compose). minSdk 24, targetSdk 34.

## Compiler
1. Installer Android Studio (Koala ou plus récent, JDK 17 inclus).
2. File > Open > dossier NEXMANAGER, attendre la synchronisation Gradle.
3. Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk
   (ou en ligne de commande : ./gradlew assembleDebug ; si gradlew est absent : gradle wrapper --gradle-version 8.7)
4. Release signée : Build > Generate Signed App Bundle / APK.

## Logo
Remplacer app/src/main/res/drawable/ic_nexcode_logo.xml (ou ajouter un PNG du même nom) par le vrai logo NEXCODE.

## Transfert (v1.1)
- Appui long = sélection multiple ; Copier / Déplacer / Supprimer ; « Coller ici » avec confirmation et barre de progression.
- Onglet Transfert : stockage interne, carte SD, clé USB/OTG (détectés via StorageManager), choix d'un dossier via SAF.
- Applications installées : export de l'APK (Téléchargements/NEXMANAGER) ou partage ; jamais de données privées.
