package com.nexcode.nexmanager

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

// ---------- Intents ----------

private fun uriFor(ctx: Context, f: File) =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

private fun mimeOf(f: File): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

fun openFile(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(ctx, f), mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "Aucune application pour ouvrir ce fichier", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Impossible d'ouvrir ce fichier", Toast.LENGTH_SHORT).show()
    }
}

fun shareFile(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_SEND)
            .setType(mimeOf(f))
            .putExtra(Intent.EXTRA_STREAM, uriFor(ctx, f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Partager"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Partage impossible", Toast.LENGTH_SHORT).show()
    }
}

// ---------- Composants communs ----------

@Composable
fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(NexGradient)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(
    f: File,
    showPath: Boolean,
    onClick: () -> Unit,
    actions: List<Pair<String, () -> Unit>>,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null
) {
    var expanded by remember { mutableStateOf(false) }
    val sub = remember(f.absolutePath) {
        val parts = ArrayList<String>()
        parts.add(FileRepo.kind(f))
        if (f.isFile) parts.add(FileRepo.humanSize(f.length()))
        parts.add(FileRepo.date(f.lastModified()))
        parts.joinToString(" · ")
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) NexBlue.copy(alpha = 0.18f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) { Text(if (selected) "✅" else FileRepo.emoji(f), fontSize = 24.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (showPath) {
                Text(
                    f.parent ?: "", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (actions.isNotEmpty()) {
            Box {
                IconButton(onClick = { expanded = true }) { Text("⋮", fontSize = 22.sp) }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    actions.forEach { (label, act) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { expanded = false; act() })
                    }
                }
            }
        }
    }
}

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onOk(text) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

// ---------- Application ----------

@Composable
fun NexApp(vm: MainViewModel, onPickTree: () -> Unit) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snackbar.showSnackbar(it)
            vm.message = null
        }
    }
    val tabs = listOf(
        "🏠" to "Accueil", "📁" to "Fichiers", "🔁" to "Transfert", "🔍" to "Recherche", "⚙️" to "Paramètres"
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, (emoji, label) ->
                    NavigationBarItem(
                        selected = vm.tab == i || (i == 2 && vm.tab == 5),
                        onClick = { vm.tab = i },
                        icon = { Text(emoji, fontSize = 22.sp) },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = NexBlue.copy(alpha = 0.28f)
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (vm.tab) {
                0 -> HomeScreen(vm)
                1 -> FilesScreen(vm)
                2 -> TransferScreen(vm, onPickTree)
                3 -> SearchScreen(vm)
                4 -> SettingsScreen(vm)
                else -> AppsScreen(vm)
            }
            TransferDialog(vm)
        }
    }
}

@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_nexcode_logo), null, Modifier.size(84.dp))
        Spacer(Modifier.height(16.dp))
        Text("NEXMANAGER", style = TextStyle(brush = NexGradient, fontSize = 28.sp, fontWeight = FontWeight.Black))
        Text("by NEXCODE", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Text(
            "Pour parcourir et gérer vos fichiers, NEXMANAGER a besoin de l'accès aux fichiers de l'appareil.\n\n" +
                "Aucune donnée n'est collectée ni envoyée : tout reste sur votre téléphone.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        GradientButton("Autoriser l'accès", onGrant, Modifier.fillMaxWidth())
    }
}

// ---------- Accueil ----------

@Composable
fun HomeScreen(vm: MainViewModel) {
    val (total, free) = vm.storage
    val used = total - free
    val frac = if (total > 0) used.toFloat() / total else 0f

    @Suppress("DEPRECATION")
    val cards = listOf(
        Triple("📷", "Images", Environment.DIRECTORY_PICTURES),
        Triple("🎥", "Vidéos", Environment.DIRECTORY_MOVIES),
        Triple("🎵", "Musique", Environment.DIRECTORY_MUSIC),
        Triple("📄", "Documents", Environment.DIRECTORY_DOCUMENTS),
        Triple("📦", "Téléchargements", Environment.DIRECTORY_DOWNLOADS)
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_nexcode_logo), null, Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("NEXMANAGER", style = TextStyle(brush = NexGradient, fontSize = 28.sp, fontWeight = FontWeight.Black))
                Text("by NEXCODE", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(20.dp))

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Stockage interne", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { frac },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                    color = NexViolet,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Utilisé : ${FileRepo.humanSize(used)}", fontSize = 13.sp)
                    Text("Disponible : ${FileRepo.humanSize(free)}", fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        cards.chunked(2).forEach { rowCards ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowCards.forEach { (emoji, label, folder) ->
                    Card(
                        Modifier
                            .weight(1f)
                            .padding(bottom = 12.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { vm.browse(folder) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(emoji, fontSize = 34.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(label, fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 14.sp)
                        }
                    }
                }
                if (rowCards.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(4.dp))
        GradientButton("📁  Parcourir les fichiers", { vm.browse(null) }, Modifier.fillMaxWidth())
    }
}

// ---------- Fichiers ----------

@Composable
fun FilesScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var renameT by remember { mutableStateOf<File?>(null) }
    var deleteT by remember { mutableStateOf<List<File>?>(null) }
    var newFolder by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var confirmPaste by remember { mutableStateOf(false) }
    val selecting = vm.selected.isNotEmpty()

    BackHandler(enabled = vm.tab == 1 && (selecting || !vm.atRoot)) {
        if (selecting) vm.clearSelection() else vm.up()
    }

    val label = vm.baseLabel + vm.dir.absolutePath.removePrefix(vm.base.absolutePath)

    Column(Modifier.fillMaxSize()) {
        if (selecting) {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.clearSelection() }) { Text("✖️", fontSize = 18.sp) }
                Text("${vm.selected.size} sélectionné(s)", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                TextButton(onClick = { vm.setClip(vm.selectedFiles(), false) }) { Text("Copier", fontSize = 13.sp) }
                TextButton(onClick = { vm.setClip(vm.selectedFiles(), true) }) { Text("Déplacer", fontSize = 13.sp) }
                TextButton(onClick = { deleteT = vm.selectedFiles() }) {
                    Text("Supprimer", fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!vm.atRoot) IconButton(onClick = { vm.up() }) { Text("⬅️", fontSize = 20.sp) }
                Text(
                    label, Modifier.weight(1f).padding(start = 8.dp), maxLines = 1,
                    overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold
                )
                IconButton(onClick = { newFolder = true }) { Text("➕", fontSize = 20.sp) }
                Box {
                    IconButton(onClick = { sortMenu = true }) { Text("↕️", fontSize = 20.sp) }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf(SortBy.NAME to "Trier par nom", SortBy.SIZE to "Trier par taille", SortBy.DATE to "Trier par date")
                            .forEach { (s, l) ->
                                DropdownMenuItem(
                                    text = { Text((if (vm.sort == s) "✓ " else "") + l) },
                                    onClick = { sortMenu = false; vm.setSort(s) }
                                )
                            }
                    }
                }
            }
        }

        if (vm.clip.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${vm.clip.size} élément(s) à " + if (vm.clipCut) "déplacer" else "copier",
                    Modifier.weight(1f), fontSize = 13.sp
                )
                TextButton(onClick = { if (vm.clipNeedsConfirm) confirmPaste = true else vm.paste() }) {
                    Text("Coller ici", color = NexBlue, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = { vm.clearClip() }) { Text("Annuler") }
            }
        }

        if (vm.items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Dossier vide", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(vm.items, key = { it.absolutePath }) { f ->
                    val actions = buildList<Pair<String, () -> Unit>> {
                        if (f.isFile) {
                            add("Ouvrir" to { openFile(ctx, f) })
                            add("Partager" to { shareFile(ctx, f) })
                        }
                        add("Sélectionner" to { vm.toggleSelect(f) })
                        add("Renommer" to { renameT = f })
                        add("Copier" to { vm.copyToClip(f) })
                        add("Déplacer" to { vm.cutToClip(f) })
                        add("Supprimer" to { deleteT = listOf(f) })
                    }
                    FileRow(
                        f, showPath = false,
                        onClick = {
                            when {
                                selecting -> vm.toggleSelect(f)
                                f.isDirectory -> vm.openDir(f)
                                else -> openFile(ctx, f)
                            }
                        },
                        actions = if (selecting) emptyList() else actions,
                        selected = f.absolutePath in vm.selected,
                        onLongClick = { vm.toggleSelect(f) }
                    )
                }
            }
        }
    }

    renameT?.let { f ->
        NameDialog("Renommer", f.name, { renameT = null }) { vm.rename(f, it); renameT = null }
    }
    if (newFolder) {
        NameDialog("Nouveau dossier", "", { newFolder = false }) { vm.mkdir(it); newFolder = false }
    }
    deleteT?.let { list ->
        AlertDialog(
            onDismissRequest = { deleteT = null },
            title = { Text("Supprimer ?") },
            text = {
                Text(
                    if (list.size == 1) {
                        "« ${list[0].name} » sera supprimé définitivement" +
                            if (list[0].isDirectory) " avec tout son contenu." else "."
                    } else {
                        "${list.size} éléments seront supprimés définitivement (dossiers avec leur contenu)."
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.deleteMany(list); deleteT = null }) {
                    Text("Supprimer", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { deleteT = null }) { Text("Annuler") } }
        )
    }
    if (confirmPaste) {
        val dirs = vm.clip.count { it.isDirectory }
        AlertDialog(
            onDismissRequest = { confirmPaste = false },
            title = { Text(if (vm.clipCut) "Déplacer ici ?" else "Copier ici ?") },
            text = {
                Text(
                    "${vm.clip.size} élément(s)" +
                        (if (dirs > 0) ", dont $dirs dossier(s) avec tout leur contenu," else "") +
                        " vers :\n$label" +
                        (if (vm.clipCut) "\n\nLes originaux seront supprimés après le transfert." else "")
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmPaste = false; vm.paste() }) {
                    Text("Confirmer", color = NexBlue, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmPaste = false }) { Text("Annuler") } }
        )
    }
}

// ---------- Recherche ----------

@Composable
fun SearchScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(top = 8.dp)) {
        OutlinedTextField(
            value = vm.searchQuery,
            onValueChange = { vm.search(it) },
            label = { Text("Rechercher un fichier ou un dossier") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(8.dp))
        when {
            vm.searching -> Text("Recherche en cours…", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            vm.searchQuery.isNotBlank() && vm.searchResults.isEmpty() ->
                Text("Aucun résultat", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(vm.searchResults, key = { it.absolutePath }) { f ->
                    val actions = buildList<Pair<String, () -> Unit>> {
                        if (f.isFile) add("Ouvrir" to { openFile(ctx, f) })
                        add("Voir le dossier" to { (if (f.isDirectory) f else f.parentFile)?.let { vm.goTo(it) }; Unit })
                    }
                    FileRow(
                        f, showPath = true,
                        onClick = { if (f.isDirectory) vm.goTo(f) else openFile(ctx, f) },
                        actions = actions
                    )
                }
            }
        }
    }
}

// ---------- Paramètres ----------

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0"
    }
    val cardColors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Paramètres", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = cardColors) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (vm.dark) "🌙  Mode sombre" else "☀️  Mode clair", Modifier.weight(1f))
                Switch(checked = vm.dark, onCheckedChange = { vm.setDark(it) })
            }
        }
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = cardColors) {
            Column(Modifier.padding(16.dp)) {
                Text("Tri par défaut", fontWeight = FontWeight.SemiBold)
                listOf(SortBy.NAME to "Nom", SortBy.SIZE to "Taille", SortBy.DATE to "Date").forEach { (s, l) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.setSort(s) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = vm.sort == s, onClick = { vm.setSort(s) })
                        Text(l)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = cardColors) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_nexcode_logo), null, Modifier.size(64.dp))
                Spacer(Modifier.height(8.dp))
                Text("NEXMANAGER", style = TextStyle(brush = NexGradient, fontSize = 22.sp, fontWeight = FontWeight.Black))
                Text("Version $version")
                Text("Développé par NEXCODE", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Gestionnaire de fichiers simple et léger. Aucun compte, aucune publicité, " +
                        "aucune donnée collectée, fonctionne hors ligne.",
                    fontSize = 12.sp, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
