package com.nexcode.nexmanager

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val NexBlue = Color(0xFF2F6BFF)
val NexViolet = Color(0xFF8B3DFF)
val NexGradient = Brush.linearGradient(listOf(NexBlue, NexViolet))

private val DarkColors = darkColorScheme(
    primary = NexBlue,
    secondary = NexViolet,
    background = Color(0xFF0E0F14),
    surface = Color(0xFF171923),
    surfaceVariant = Color(0xFF212436),
    onBackground = Color(0xFFE8EAF2),
    onSurface = Color(0xFFE8EAF2),
    onSurfaceVariant = Color(0xFF9AA0B5),
    error = Color(0xFFFF5470)
)

private val LightColors = lightColorScheme(
    primary = NexBlue,
    secondary = NexViolet,
    background = Color(0xFFF5F6FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFE9EBF5),
    onBackground = Color(0xFF14151C),
    onSurface = Color(0xFF14151C),
    onSurfaceVariant = Color(0xFF5B6075),
    error = Color(0xFFD62F4B)
)

@Composable
fun NexTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
