package com.nexcode.nexmanager

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AppInfo(
    val label: String, val pkg: String, val apk: String, val version: String,
    val system: Boolean, val split: Boolean, val size: Long
)

data class TransferState(
    val title: String,
    val current: String = "",
    val done: Long = 0L,
    val total: Long = 0L,
    val finished: Boolean = false,
    val error: String? = null,
    val shareFile: File? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("nexmanager", Context.MODE_PRIVATE)

    // 0 Accueil, 1 Fichiers, 2 Transfert, 3 Recherche, 4 Paramètres, 5 Applications (sous-écran de Transfert)
    var tab by mutableStateOf(0)
    var message by mutableStateOf<String?>(null)

    var dark by mutableStateOf(prefs.getBoolean("dark", true)); private set
    var sort by mutableStateOf(
        runCatching { SortBy.valueOf(prefs.getString("sort", "NAME") ?: "NAME") }.getOrDefault(SortBy.NAME)
    ); private set

    var base by mutableStateOf(FileRepo.root); private set
    var baseLabel by mutableStateOf("Stockage interne"); private set
    var dir by mutableStateOf(FileRepo.root); private set
    var items by mutableStateOf<List<File>>(emptyList()); private set
    var storage by mutableStateOf(0L to 0L); private set
    var volumes by mutableStateOf<List<Volume>>(emptyList()); private set

    var selected by mutableStateOf<Set<String>>(emptySet()); private set
    var clip by mutableStateOf<List<File>>(emptyList()); private set
    var clipCut by mutableStateOf(false); private set

    var searchQuery by mutableStateOf(""); private set
    var searchResults by mutableStateOf<List<File>>(emptyList()); private set
    var searching by mutableStateOf(false); private set
    private var searchJob: Job? = null

    var transfer by mutableStateOf<TransferState?>(null); private set
    private var transferJob: Job? = null

    var apps by mutableStateOf<List<AppInfo>>(emptyList()); private set

    val atRoot: Boolean get() = dir.absolutePath == base.absolutePath
    val clipNeedsConfirm: Boolean get() = clip.size > 1 || clip.any { it.isDirectory } || clipCut

    fun refresh() {
        val d = dir
        val s = sort
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                Triple(FileRepo.list(d, s), FileRepo.storage(), FileRepo.volumes(getApplication<Application>()))
            }
            items = r.first
            storage = r.second
            volumes = r.third
        }
    }

    private fun io(block: () -> String) {
        viewModelScope.launch {
            message = withContext(Dispatchers.IO) { block() }
            refresh()
        }
    }

    // --- Navigation ---
    fun goTo(d: File) {
        base = FileRepo.root
        baseLabel = "Stockage interne"
        dir = d
        selected = emptySet()
        tab = 1
        refresh()
    }

    fun goToVolume(v: Volume) {
        base = v.dir
        baseLabel = v.label
        dir = v.dir
        selected = emptySet()
        tab = 1
        refresh()
    }

    fun openDir(d: File) {
        if (d.isDirectory) { dir = d; selected = emptySet(); refresh() }
    }

    fun up() {
        val p = dir.parentFile
        if (!atRoot && p != null && FileRepo.isSafe(p)) { dir = p; selected = emptySet(); refresh() }
    }

    @Suppress("DEPRECATION")
    fun browse(folderType: String?) {
        val f = folderType?.let { Environment.getExternalStoragePublicDirectory(it) }
        goTo(if (f != null && f.isDirectory) f else FileRepo.root)
    }

    // --- Réglages ---
    fun setDark(v: Boolean) { dark = v; prefs.edit().putBoolean("dark", v).apply() }

    fun setSort(s: SortBy) {
        sort = s
        prefs.edit().putString("sort", s.name).apply()
        refresh()
    }

    // --- Sélection ---
    fun toggleSelect(f: File) {
        val p = f.absolutePath
        selected = if (p in selected) selected - p else selected + p
    }

    fun clearSelection() { selected = emptySet() }
    fun selectedFiles(): List<File> = items.filter { it.absolutePath in selected }

    // --- Actions simples ---
    fun rename(f: File, name: String) = io {
        if (FileRepo.rename(f, name)) "Renommé" else "Renommage impossible (nom invalide ou déjà utilisé)"
    }

    fun mkdir(name: String) {
        val d = dir
        io { if (FileRepo.mkdir(d, name)) "Dossier créé" else "Création impossible" }
    }

    fun deleteMany(files: List<File>) {
        selected = emptySet()
        io {
            var ok = 0
            for (f in files) if (FileRepo.delete(f)) ok++
            if (ok == files.size) "Supprimé" else "$ok/${files.size} supprimé(s)"
        }
    }

    // --- Presse-papiers ---
    fun setClip(files: List<File>, cut: Boolean) {
        clip = files
        clipCut = cut
        selected = emptySet()
        message = "${files.size} élément(s) " + if (cut) "prêt(s) à déplacer" else "prêt(s) à copier"
    }

    fun copyToClip(f: File) = setClip(listOf(f), false)
    fun cutToClip(f: File) = setClip(listOf(f), true)
    fun clearClip() { clip = emptyList() }

    // --- Transfert (avec progression) ---
    private fun launchTransfer(
        title: String,
        shareFile: File? = null,
        work: ((String, Long, Long) -> Unit, () -> Boolean) -> String?
    ) {
        if (transfer?.finished == false) return
        transfer = TransferState(title, "Préparation…")
        var done = 0L
        var total = 0L
        transferJob = viewModelScope.launch {
            try {
                val err = withContext(Dispatchers.IO) {
                    try {
                        work({ n, d, t -> done = d; total = t; transfer = TransferState(title, n, d, t) }, { !isActive })
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Transfer.friendly(e)
                    }
                }
                transfer = TransferState(
                    title, finished = true, done = if (err == null) total else done, total = total,
                    error = err, shareFile = if (err == null) shareFile else null
                )
                refresh()
            } catch (e: CancellationException) {
                transfer = null
                message = "Transfert annulé"
                refresh()
                throw e
            }
        }
    }

    fun paste() {
        val files = clip
        val cut = clipCut
        val target = dir
        clip = emptyList()
        launchTransfer(if (cut) "Déplacement en cours…" else "Copie en cours…") { pub, canc ->
            Transfer.runLocal(files, target, cut, pub, canc)
        }
    }

    /** Destination choisie avec le Storage Access Framework (carte SD, clé USB…). */
    fun transferToTree(tree: Uri) {
        val files = clip
        val cut = clipCut
        if (files.isEmpty()) { message = "Rien à transférer"; return }
        clip = emptyList()
        val ctx = getApplication<Application>()
        launchTransfer(if (cut) "Déplacement vers l'emplacement choisi…" else "Copie vers l'emplacement choisi…") { pub, canc ->
            Transfer.runTree(ctx, files, tree, cut, pub, canc)
        }
    }

    fun cancelTransfer() { transferJob?.cancel() }

    fun dismissTransfer() {
        transfer = null
        refresh()
    }

    // --- Applications installées ---
    fun openApps() {
        tab = 5
        if (apps.isNotEmpty()) return
        viewModelScope.launch {
            apps = withContext(Dispatchers.IO) {
                val pm = getApplication<Application>().packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
                    val ai = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
                    val version = try { pm.getPackageInfo(ai.packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        pkg = ai.packageName,
                        apk = ai.sourceDir ?: "",
                        version = version,
                        system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                        split = !ai.splitSourceDirs.isNullOrEmpty(),
                        size = try { File(ai.sourceDir).length() } catch (e: Exception) { 0L }
                    )
                }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
            }
        }
    }

    /** Exporte l'APK (public) d'une application : dans Téléchargements/NEXMANAGER, ou vers le menu Partager. */
    fun exportApk(a: AppInfo, share: Boolean) {
        val ctx = getApplication<Application>()
        val safe = a.label.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val name = "${safe}_${a.version}.apk"
        val shareDst = File(File(ctx.cacheDir, "apk"), name)
        launchTransfer(
            if (share) "Préparation de l'APK…" else "Export de l'APK…",
            if (share) shareDst else null
        ) { pub, canc ->
            val dst = if (share) {
                shareDst.parentFile?.apply { deleteRecursively(); mkdirs() }
                shareDst
            } else {
                @Suppress("DEPRECATION")
                val dl = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NEXMANAGER")
                FileRepo.uniqueTarget(dl, name)
            }
            Transfer.runApk(File(a.apk), dst, pub, canc)
        }
    }

    // --- Recherche ---
    fun search(q: String) {
        searchQuery = q
        searchJob?.cancel()
        if (q.isBlank()) { searchResults = emptyList(); searching = false; return }
        searchJob = viewModelScope.launch {
            searching = true
            delay(300)
            val r = withContext(Dispatchers.IO) { FileRepo.search(q) }
            searchResults = r
            searching = false
        }
    }
}
