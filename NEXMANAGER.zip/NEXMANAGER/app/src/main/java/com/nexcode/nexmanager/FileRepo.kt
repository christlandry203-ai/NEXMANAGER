package com.nexcode.nexmanager

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.os.StatFs
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

enum class SortBy { NAME, SIZE, DATE }

/** Toutes les opérations sont limitées au stockage partagé : jamais de fichiers système. */
object FileRepo {

    val root: File get() = Environment.getExternalStorageDirectory()

    /** Racines des cartes SD / clés USB détectées (mises à jour par volumes()). */
    @Volatile var extraRoots: List<File> = emptyList()

    private fun roots(): List<File> = listOf(root) + extraRoots

    fun isSafe(f: File): Boolean = try {
        val c = f.canonicalPath
        roots().any { c.startsWith(it.canonicalPath) }
    } catch (e: Exception) {
        false
    }

    fun list(dir: File, sort: SortBy): List<File> {
        val files = dir.listFiles()?.toList() ?: emptyList()
        val cmp: Comparator<File> = when (sort) {
            SortBy.NAME -> compareBy<File> { it.name.lowercase() }
            SortBy.SIZE -> compareByDescending<File> { it.length() }
            SortBy.DATE -> compareByDescending<File> { it.lastModified() }
        }
        return files.sortedWith(compareBy<File> { !it.isDirectory }.then(cmp))
    }

    suspend fun search(query: String, limit: Int = 300): List<File> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        val out = ArrayList<File>()
        val stack = ArrayList<Pair<File, Int>>()
        stack.add(root to 0)
        while (stack.isNotEmpty() && out.size < limit) {
            currentCoroutineContext().ensureActive()
            val (d, depth) = stack.removeAt(stack.lastIndex)
            val children = d.listFiles() ?: continue
            for (c in children) {
                if (c.name.lowercase().contains(q)) out.add(c)
                if (c.isDirectory && depth < 8) stack.add(c to depth + 1)
            }
        }
        return out
    }

    fun uniqueTarget(dir: File, name: String): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            t = File(dir, "$base ($i)$ext")
            if (!t.exists()) return t
            i++
        }
    }

    fun copy(src: File, destDir: File): Boolean {
        if (!isSafe(src) || !isSafe(destDir) || !src.exists()) return false
        if (src.isDirectory && destDir.canonicalPath.startsWith(src.canonicalPath)) return false
        val target = uniqueTarget(destDir, src.name)
        return try {
            if (src.isDirectory) src.copyRecursively(target, overwrite = false)
            else { src.copyTo(target, overwrite = false); true }
        } catch (e: Exception) {
            false
        }
    }

    fun move(src: File, destDir: File): Boolean {
        if (!isSafe(src) || !isSafe(destDir) || !src.exists()) return false
        if (src.parentFile?.canonicalPath == destDir.canonicalPath) return true
        if (src.isDirectory && destDir.canonicalPath.startsWith(src.canonicalPath)) return false
        val target = uniqueTarget(destDir, src.name)
        if (src.renameTo(target)) return true
        return copy(src, destDir) && delete(src)
    }

    fun delete(f: File): Boolean = try {
        isSafe(f) && roots().none { it.canonicalPath == f.canonicalPath } && f.deleteRecursively()
    } catch (e: Exception) {
        false
    }

    fun rename(f: File, newName: String): Boolean {
        val n = newName.trim()
        if (n.isEmpty() || n.contains('/') || !isSafe(f)) return false
        val target = File(f.parentFile, n)
        if (target.exists()) return false
        return f.renameTo(target)
    }

    fun mkdir(parent: File, name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/') || !isSafe(parent)) return false
        val d = File(parent, n)
        return !d.exists() && d.mkdir()
    }

    /** (total, libre) en octets */
    fun storage(): Pair<Long, Long> = try {
        val s = StatFs(root.path)
        s.totalBytes to s.availableBytes
    } catch (e: Exception) {
        0L to 0L
    }

    /** Stockage interne + cartes SD / clés USB montées (API officielles). */
    fun volumes(ctx: Context): List<Volume> {
        fun stat(d: File): Pair<Long, Long> = try {
            val s = StatFs(d.path); s.totalBytes to s.availableBytes
        } catch (e: Exception) { 0L to 0L }

        val out = ArrayList<Volume>()
        val (t0, f0) = stat(root)
        out.add(Volume("Stockage interne", "📱", root, t0, f0))
        val found = ArrayList<Pair<File, String>>()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
                for (v in sm.storageVolumes) {
                    if (v.isPrimary) continue
                    val d = v.directory ?: continue
                    if (v.state == Environment.MEDIA_MOUNTED) found.add(d to (v.getDescription(ctx) ?: ""))
                }
            } else {
                ctx.getExternalFilesDirs(null).drop(1).filterNotNull().forEach { f ->
                    val i = f.absolutePath.indexOf("/Android/")
                    if (i > 0) found.add(File(f.absolutePath.substring(0, i)) to "")
                }
            }
        } catch (e: Exception) { /* ignoré */ }
        for ((d, desc) in found) {
            if (!d.exists()) continue
            val usb = desc.contains("usb", true) || desc.contains("otg", true)
            val label = when {
                usb -> "Clé USB / OTG"
                desc.isBlank() -> "Carte SD / USB"
                else -> "Carte SD"
            }
            val (t, f) = stat(d)
            out.add(Volume(label, if (usb) "🔌" else "💳", d, t, f))
        }
        extraRoots = out.drop(1).map { it.dir }
        return out
    }

    fun humanSize(b: Long): String {
        if (b < 1024) return "$b o"
        val units = arrayOf("Ko", "Mo", "Go", "To")
        var v = b.toDouble()
        var i = -1
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return String.format(Locale.getDefault(), "%.1f %s", v, units[i])
    }

    fun date(ms: Long): String =
        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

    fun kind(f: File): String {
        if (f.isDirectory) return "Dossier"
        return when (val e = f.extension.lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic" -> "Image"
            "mp4", "mkv", "avi", "3gp", "webm", "mov" -> "Vidéo"
            "mp3", "wav", "ogg", "m4a", "flac", "aac" -> "Audio"
            "pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx", "odt", "csv" -> "Document"
            "zip", "rar", "7z", "tar", "gz" -> "Archive"
            "apk" -> "Application"
            "" -> "Fichier"
            else -> e.uppercase()
        }
    }

    fun emoji(f: File): String = when (kind(f)) {
        "Dossier" -> "📁"
        "Image" -> "🖼️"
        "Vidéo" -> "🎬"
        "Audio" -> "🎵"
        "Document" -> "📄"
        "Archive" -> "🗜️"
        "Application" -> "🤖"
        else -> "📃"
    }
}

data class Volume(val label: String, val emoji: String, val dir: File, val total: Long, val free: Long)
