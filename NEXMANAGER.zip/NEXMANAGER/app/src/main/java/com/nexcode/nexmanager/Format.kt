package com.nexcode.nexmanager

object Format {
    fun duration(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return when {
            s < 60 -> "$s s"
            s < 3600 -> "${s / 60} min ${s % 60} s"
            else -> "${s / 3600} h ${(s % 3600) / 60} min"
        }
    }

    fun speed(bytesPerSec: Double): String = FileRepo.humanSize(bytesPerSec.toLong()) + "/s"
}
