package com.nexcode.nexmanager

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------- Composants communs ----------

@Composable
private fun GradientBar(frac: Float, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().background(NexGradient))
    }
}

@Composable
private fun SoftCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth().padding(bottom = 10.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
}

@Composable
private fun StepRow(number: Int, title: String, subtitle: String, done: Boolean, active: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        val badge = Modifier.size(30.dp).clip(CircleShape)
        Box(
            if (active || done) badge.background(NexGradient) else badge.background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (done) "✓" else number.toString(),
                color = if (active || done) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ModeChoice(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) NexBlue.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp)
    }
}

@Composable
private fun QuickDest(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 24.sp)
            Text(label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun NavCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", fontSize = 22.sp)
        }
    }
}

// ---------- Onglet Transfert ----------

@Composable
fun TransferScreen(vm: MainViewModel, onPickTree: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val hasClip = vm.clip.isNotEmpty()
    var confirm by remember { mutableStateOf(false) }
    val curName = if (vm.atRoot) vm.baseLabel else vm.dir.name

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Transfert", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Copiez ou déplacez fichiers et dossiers vers un autre emplacement.", fontSize = 13.sp, color = muted)
        Spacer(Modifier.height(14.dp))

        SoftCard {
            StepRow(1, "Sélectionner", "Appui long sur un élément dans Fichiers", done = hasClip, active = !hasClip)
            StepRow(2, "Choisir la destination", "Stockage, carte SD, clé USB ou dossier", done = false, active = hasClip)
            StepRow(3, "Coller ici", "Confirmer, puis suivre la progression", done = false, active = false)
        }

        SoftCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Éléments à transférer", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (hasClip) TextButton(onClick = { vm.clearClip() }) { Text("Vider") }
            }
            if (!hasClip) {
                Text(
                    "Rien de sélectionné pour l'instant. Dans l'onglet Fichiers, fais un appui long sur un fichier ou un dossier, puis choisis Copier ou Déplacer.",
                    fontSize = 13.sp, color = muted
                )
                Spacer(Modifier.height(10.dp))
                GradientButton("📁  Ouvrir Fichiers", { vm.tab = 1 }, Modifier.fillMaxWidth())
            } else {
                Text(
                    "${vm.clip.size} élément(s)" +
                        (if (vm.clipSize >= 0) " · " + FileRepo.humanSize(vm.clipSize) else " · calcul de la taille…"),
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChoice("📋  Copier", !vm.clipCut, Modifier.weight(1f)) { if (vm.clipCut) vm.toggleClipMode() }
                    ModeChoice("✂️  Déplacer", vm.clipCut, Modifier.weight(1f)) { if (!vm.clipCut) vm.toggleClipMode() }
                }
                Spacer(Modifier.height(8.dp))
                vm.clip.take(5).forEach { f ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(FileRepo.emoji(f), fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text(
                                if (f.isDirectory) "Dossier" else FileRepo.humanSize(f.length()),
                                fontSize = 11.sp, color = muted
                            )
                        }
                        IconButton(onClick = { vm.removeFromClip(f) }) { Text("✕", fontSize = 16.sp) }
                    }
                }
                if (vm.clip.size > 5) Text("+ ${vm.clip.size - 5} autre(s)", fontSize = 12.sp, color = muted)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (vm.clipCut) "Les originaux seront supprimés après le transfert."
                    else "Les originaux sont conservés.",
                    fontSize = 12.sp, color = muted
                )
            }
        }

        SectionTitle("Destination rapide")
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            @Suppress("DEPRECATION")
            val dl = android.os.Environment.DIRECTORY_DOWNLOADS
            @Suppress("DEPRECATION")
            val docs = android.os.Environment.DIRECTORY_DOCUMENTS
            @Suppress("DEPRECATION")
            val pics = android.os.Environment.DIRECTORY_PICTURES
            QuickDest("📦", "Téléchargements", Modifier.weight(1f)) { vm.browse(dl) }
            QuickDest("📄", "Documents", Modifier.weight(1f)) { vm.browse(docs) }
            QuickDest("📷", "Images", Modifier.weight(1f)) { vm.browse(pics) }
        }

        SectionTitle("Emplacements")
        vm.volumes.forEach { v ->
            val used = (v.total - v.free).coerceAtLeast(0L)
            val frac = if (v.total > 0) used.toFloat() / v.total else 0f
            Card(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(18.dp)).clickable { vm.goToVolume(v) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(v.emoji, fontSize = 30.sp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(v.label, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        GradientBar(frac)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${FileRepo.humanSize(v.free)} libres sur ${FileRepo.humanSize(v.total)}",
                            fontSize = 12.sp, color = muted
                        )
                    }
                    Text("›", fontSize = 22.sp)
                }
            }
        }
        if (vm.volumes.size <= 1) {
            Text("Aucune carte SD ni clé USB/OTG détectée. Branche-en une pour la voir ici.", fontSize = 12.sp, color = muted)
        }

        Spacer(Modifier.height(12.dp))
        if (hasClip) {
            GradientButton(
                "📥  Coller dans « $curName »",
                { if (vm.clipNeedsConfirm) confirm = true else vm.paste() },
                Modifier.fillMaxWidth()
            )
            Text(
                "Dossier actuel : ${vm.baseLabel}${vm.dir.absolutePath.removePrefix(vm.base.absolutePath)}",
                fontSize = 11.sp, color = muted, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
            )
        }
        GradientButton(
            "💳  Choisir un dossier (SAF) sur SD / USB",
            {
                if (vm.clip.isEmpty()) vm.message = "Sélectionne d'abord des éléments dans Fichiers"
                else onPickTree()
            },
            Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Android te demande d'autoriser un dossier de destination. À utiliser si la carte SD ou la clé USB n'est pas accessible directement (surtout sous Android 10 et moins).",
            fontSize = 12.sp, color = muted
        )

        if (vm.recent.isNotEmpty()) {
            SectionTitle("Derniers transferts")
            vm.recent.forEach { r ->
                SoftCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (r.ok) "✅" else "⚠️", fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(r.summary, fontSize = 12.sp, color = muted)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        NavCard("📲", "Applications installées", "Exporter ou partager l'APK d'une application") { vm.openApps() }
    }

    if (confirm) {
        val dirs = vm.clip.count { it.isDirectory }
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(if (vm.clipCut) "Déplacer ici ?" else "Copier ici ?") },
            text = {
                Text(
                    "${vm.clip.size} élément(s)" +
                        (if (vm.clipSize >= 0) " (" + FileRepo.humanSize(vm.clipSize) + ")" else "") +
                        (if (dirs > 0) ", dont $dirs dossier(s) avec tout leur contenu," else "") +
                        " vers :\n${vm.baseLabel}${vm.dir.absolutePath.removePrefix(vm.base.absolutePath)}" +
                        (if (vm.clipCut) "\n\nLes originaux seront supprimés après le transfert." else "")
                )
            },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.paste() }) {
                    Text("Confirmer", color = NexBlue, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Annuler") } }
        )
    }
}

// ---------- Applications installées ----------

@Composable
fun AppsScreen(vm: MainViewModel) {
    var showSystem by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<AppInfo?>(null) }
    BackHandler(enabled = vm.tab == 5) { vm.tab = 2 }
    val list = vm.apps.filter { showSystem || !it.system }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.tab = 2 }) { Text("⬅️", fontSize = 20.sp) }
            Text("Applications installées", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Afficher les applications système", Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = showSystem, onCheckedChange = { showSystem = it })
        }
        if (vm.apps.isEmpty()) {
            Text("Chargement…", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.pkg }) { a -> AppRow(a) { sel = a } }
            }
        }
    }

    sel?.let { a ->
        AlertDialog(
            onDismissRequest = { sel = null },
            title = { Text(a.label) },
            text = {
                Column {
                    Text("${a.pkg}\nVersion ${a.version} • APK ${FileRepo.humanSize(a.size)}", fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    if (a.split) {
                        Text(
                            "⚠️ Cette application utilise plusieurs APK : seul l'APK de base est exporté, " +
                                "il ne suffira pas à la réinstaller.",
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        "Seul l'APK est exporté (dans Téléchargements/NEXMANAGER). Les données privées " +
                            "de l'application ne sont jamais accessibles.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { vm.exportApk(a, false); sel = null }) { Text("Enregistrer") }
                    TextButton(onClick = { vm.exportApk(a, true); sel = null }) { Text("Partager") }
                }
            },
            dismissButton = { TextButton(onClick = { sel = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun AppRow(a: AppInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(null, a.pkg) {
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
            val ic = icon
            if (ic != null) Image(bitmap = ic, contentDescription = null, modifier = Modifier.size(44.dp))
            else Text("📲", fontSize = 24.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                a.pkg, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(FileRepo.humanSize(a.size), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------- Fenêtre de progression ----------

@Composable
fun TransferDialog(vm: MainViewModel) {
    val t = vm.transfer ?: return
    val ctx = LocalContext.current
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val frac = if (t.total > 0) (t.done.toFloat() / t.total).coerceIn(0f, 1f) else 0f
    val elapsed = if (t.finished) t.elapsedMs else (System.currentTimeMillis() - t.startedAt)
    val speed = if (elapsed > 500 && t.done > 0) t.done * 1000.0 / elapsed else 0.0
    val remaining = if (speed > 0 && t.total > t.done) ((t.total - t.done) / speed * 1000).toLong() else -1L

    AlertDialog(
        onDismissRequest = { if (t.finished) vm.dismissTransfer() },
        title = {
            Text(
                when {
                    !t.finished -> t.title + " en cours…"
                    t.error == null -> "Transfert terminé"
                    else -> "Transfert impossible"
                }
            )
        },
        text = {
            Column(Modifier.fillMaxWidth()) {
                if (!t.finished) {
                    Text(
                        "${(frac * 100).toInt()} %",
                        style = TextStyle(brush = NexGradient, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    )
                    Spacer(Modifier.height(8.dp))
                    GradientBar(frac)
                    Spacer(Modifier.height(10.dp))
                    if (t.itemCount > 1 && t.itemIndex > 0) {
                        Text("Élément ${t.itemIndex} sur ${t.itemCount}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                    Text(t.current, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = muted)
                    Spacer(Modifier.height(10.dp))
                    Text("${FileRepo.humanSize(t.done)} / ${FileRepo.humanSize(t.total)}", fontSize = 13.sp)
                    Text(
                        if (speed > 0) "⚡ ${Format.speed(speed)}" else "⚡ mesure de la vitesse…",
                        fontSize = 13.sp
                    )
                    Text(
                        if (remaining >= 0) "⏱ environ ${Format.duration(remaining)} restantes" else "⏱ calcul du temps restant…",
                        fontSize = 13.sp
                    )
                    if (t.dest.isNotEmpty()) Text("➡ ${t.dest}", fontSize = 12.sp, color = muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                } else if (t.error != null) {
                    Text("⚠️", fontSize = 36.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Text(t.error)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Les éléments déjà transférés restent à leur place : vérifie le dossier de destination.",
                        fontSize = 12.sp, color = muted
                    )
                } else {
                    Text("✅", fontSize = 36.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Text("${t.itemCount} élément(s) · ${FileRepo.humanSize(t.total)}", fontWeight = FontWeight.SemiBold)
                    Text("Durée : ${Format.duration(t.elapsedMs)}", fontSize = 13.sp)
                    if (speed > 0) Text("Vitesse moyenne : ${Format.speed(speed)}", fontSize = 13.sp)
                    if (t.dest.isNotEmpty()) Text("Destination : ${t.dest}", fontSize = 12.sp, color = muted)
                }
            }
        },
        confirmButton = {
            if (t.finished) {
                Row {
                    if (t.error != null && vm.canRetry) {
                        TextButton(onClick = { vm.retryTransfer() }) { Text("Réessayer") }
                    }
                    t.shareFile?.let { f -> TextButton(onClick = { shareFile(ctx, f) }) { Text("Partager l'APK") } }
                    TextButton(onClick = { vm.dismissTransfer() }) { Text("Fermer") }
                }
            }
        },
        dismissButton = {
            if (!t.finished) TextButton(onClick = { vm.cancelTransfer() }) {
                Text("Annuler", color = MaterialTheme.colorScheme.error)
            }
        }
    )
}
