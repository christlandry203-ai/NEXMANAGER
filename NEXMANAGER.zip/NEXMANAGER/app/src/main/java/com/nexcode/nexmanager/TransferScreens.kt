package com.nexcode.nexmanager

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun NavCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", fontSize = 22.sp)
        }
    }
}

// ---------- Onglet Transfert ----------

@Composable
fun TransferScreen(vm: MainViewModel, onPickTree: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Transfert", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Éléments à transférer", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (vm.clip.isEmpty()) {
                    Text(
                        "Dans l'onglet Fichiers, fais un appui long sur un fichier ou un dossier pour en " +
                            "sélectionner plusieurs, puis choisis Copier ou Déplacer.",
                        fontSize = 13.sp, color = muted
                    )
                } else {
                    Text(
                        "${vm.clip.size} élément(s) à " + if (vm.clipCut) "déplacer" else "copier",
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "Choisis un emplacement ci-dessous, ouvre le dossier voulu, puis appuie sur « Coller ici ».",
                        fontSize = 13.sp, color = muted
                    )
                    TextButton(onClick = { vm.clearClip() }) { Text("Vider") }
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text("Emplacements", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        vm.volumes.forEach { v ->
            NavCard(
                v.emoji, v.label,
                "${FileRepo.humanSize(v.free)} libres sur ${FileRepo.humanSize(v.total)}"
            ) { vm.goToVolume(v) }
        }
        if (vm.volumes.size <= 1) {
            Text(
                "Aucune carte SD ni clé USB/OTG détectée. Branche-en une pour la voir ici.",
                fontSize = 12.sp, color = muted
            )
        }

        Spacer(Modifier.height(14.dp))
        GradientButton(
            "💳  Choisir un dossier (SAF) sur SD / USB",
            {
                if (vm.clip.isEmpty()) vm.message = "Sélectionne d'abord des éléments dans Fichiers"
                else onPickTree()
            },
            Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Android te demande d'autoriser un dossier de destination. À utiliser si la carte SD ou la clé USB " +
                "n'est pas accessible directement (surtout sous Android 10 et moins).",
            fontSize = 12.sp, color = muted
        )

        Spacer(Modifier.height(18.dp))
        NavCard("📲", "Applications installées", "Exporter ou partager l'APK d'une application") { vm.openApps() }
    }
}

// ---------- Applications installées ----------

@Composable
fun AppsScreen(vm: MainViewModel) {
    var showSystem by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<AppInfo?>(null) }
    BackHandler(enabled = vm.tab == 5) { vm.tab = 2 }
    val list = vm.apps.filter { showSystem || !it.system }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.tab = 2 }) { Text("⬅️", fontSize = 20.sp) }
            Text("Applications installées", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Afficher les applications système", Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = showSystem, onCheckedChange = { showSystem = it })
        }
        if (vm.apps.isEmpty()) {
            Text("Chargement…", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.pkg }) { a -> AppRow(a) { sel = a } }
            }
        }
    }

    sel?.let { a ->
        AlertDialog(
            onDismissRequest = { sel = null },
            title = { Text(a.label) },
            text = {
                Column {
                    Text("${a.pkg}\nVersion ${a.version} • APK ${FileRepo.humanSize(a.size)}", fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    if (a.split) {
                        Text(
                            "⚠️ Cette application utilise plusieurs APK : seul l'APK de base est exporté, " +
                                "il ne suffira pas à la réinstaller.",
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        "Seul l'APK est exporté (dans Téléchargements/NEXMANAGER). Les données privées " +
                            "de l'application ne sont jamais accessibles.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { vm.exportApk(a, false); sel = null }) { Text("Enregistrer") }
                    TextButton(onClick = { vm.exportApk(a, true); sel = null }) { Text("Partager") }
                }
            },
            dismissButton = { TextButton(onClick = { sel = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun AppRow(a: AppInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(null, a.pkg) {
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.packageManager.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
            val ic = icon
            if (ic != null) Image(bitmap = ic, contentDescription = null, modifier = Modifier.size(44.dp))
            else Text("📲", fontSize = 24.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                a.pkg, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(FileRepo.humanSize(a.size), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------- Fenêtre de progression ----------

@Composable
fun TransferDialog(vm: MainViewModel) {
    val t = vm.transfer ?: return
    val ctx = LocalContext.current
    val frac = if (t.total > 0) (t.done.toFloat() / t.total).coerceIn(0f, 1f) else 0f
    AlertDialog(
        onDismissRequest = { if (t.finished) vm.dismissTransfer() },
        title = {
            Text(
                when {
                    !t.finished -> t.title
                    t.error == null -> "Transfert terminé ✅"
                    else -> "Transfert impossible ⚠️"
                }
            )
        },
        text = {
            Column {
                if (!t.finished) {
                    Text(t.current, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { frac },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                        color = NexViolet,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${FileRepo.humanSize(t.done)} / ${FileRepo.humanSize(t.total)}  (${(frac * 100).toInt()} %)",
                        fontSize = 13.sp
                    )
                } else if (t.error != null) {
                    Text(t.error)
                } else {
                    Text("${FileRepo.humanSize(t.total)} transférés.")
                }
            }
        },
        confirmButton = {
            if (t.finished) {
                Row {
                    t.shareFile?.let { f -> TextButton(onClick = { shareFile(ctx, f) }) { Text("Partager l'APK") } }
                    TextButton(onClick = { vm.dismissTransfer() }) { Text("Fermer") }
                }
            }
        },
        dismissButton = {
            if (!t.finished) TextButton(onClick = { vm.cancelTransfer() }) { Text("Annuler") }
        }
    )
}
