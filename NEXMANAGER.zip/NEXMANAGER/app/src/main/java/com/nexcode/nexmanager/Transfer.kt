package com.nexcode.nexmanager

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CancellationException
import java.io.File
import java.io.IOException

/** Moteur de transfert : flux de 64 Ko (peu de RAM), progression, annulation. Tout se passe sur un thread IO. */
object Transfer {

    private class Tracker(
        private val total: Long,
        private val publish: (String, Long, Long) -> Unit,
        private val cancelled: () -> Boolean
    ) {
        private var done = 0L
        private var last = 0L
        fun add(n: Long, name: String) {
            if (cancelled()) throw CancellationException("Transfert annulé")
            done += n
            val now = System.nanoTime()
            if (now - last > 100_000_000L) { last = now; publish(name, done, total) }
        }
    }

    fun sizeOf(f: File): Long =
        if (f.isFile) f.length() else (f.listFiles()?.sumOf { sizeOf(it) } ?: 0L)

    fun friendly(e: Exception): String {
        val m = e.message ?: ""
        return when {
            m.contains("ENOSPC") || m.contains("No space", true) -> "Espace insuffisant sur la destination."
            m.contains("EACCES") || m.contains("EPERM") || m.contains("Permission denied", true) ||
                m.contains("Access denied", true) -> "Accès refusé par Android sur cet emplacement."
            m.contains("EROFS") || m.contains("Read-only", true) -> "La destination est en lecture seule."
            else -> "Erreur pendant le transfert : " + m.ifBlank { e.javaClass.simpleName }
        }
    }

    private fun checkLocal(files: List<File>, dest: File): String? {
        if (!FileRepo.isSafe(dest) || !dest.isDirectory) return "Destination invalide."
        if (!dest.canWrite()) {
            return "Ce dossier n'est pas accessible en écriture. Pour une carte SD ou une clé USB, " +
                "utilise « Choisir un dossier (SAF) » dans l'onglet Transfert."
        }
        for (f in files) {
            if (!f.exists()) return "« ${f.name} » n'existe plus."
            if (!FileRepo.isSafe(f)) return "Opération refusée sur « ${f.name} »."
            if (f.isDirectory && dest.canonicalPath.startsWith(f.canonicalPath)) {
                return "Impossible de copier un dossier dans lui-même."
            }
        }
        return null
    }

    private fun copyTree(src: File, dst: File, t: Tracker) {
        if (src.isDirectory) {
            if (!dst.mkdirs() && !dst.isDirectory) throw IOException("Création impossible : ${dst.name}")
            src.listFiles()?.forEach { copyTree(it, File(dst, it.name), t) }
        } else {
            src.inputStream().use { i ->
                dst.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        t.add(n.toLong(), src.name)
                    }
                }
            }
            dst.setLastModified(src.lastModified())
        }
    }

    /** Copie / déplacement de fichiers et dossiers vers un dossier accessible directement. Retourne null si OK, sinon l'erreur. */
    fun runLocal(
        files: List<File>, dest: File, cut: Boolean,
        publish: (String, Long, Long) -> Unit, cancelled: () -> Boolean
    ): String? {
        checkLocal(files, dest)?.let { return it }
        val sizes = files.map { sizeOf(it) }
        val total = sizes.sum()
        if (!cut) {
            val free = try { StatFs(dest.path).availableBytes } catch (e: Exception) { Long.MAX_VALUE }
            if (total > free) return "Espace insuffisant : il manque ${FileRepo.humanSize(total - free)}."
        }
        val t = Tracker(total, publish, cancelled)
        publish("", 0L, total)
        for ((i, f) in files.withIndex()) {
            val target = FileRepo.uniqueTarget(dest, f.name)
            try {
                if (cut && f.renameTo(target)) {
                    t.add(sizes[i], f.name)
                } else {
                    copyTree(f, target, t)
                    if (cut && !FileRepo.delete(f)) {
                        return "Copié, mais l'original « ${f.name} » n'a pas pu être supprimé."
                    }
                }
            } catch (e: CancellationException) {
                target.deleteRecursively()
                throw e
            } catch (e: Exception) {
                target.deleteRecursively()
                return friendly(e)
            }
        }
        return null
    }

    private fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"

    private fun copyIntoDoc(ctx: Context, src: File, parent: DocumentFile, t: Tracker) {
        if (src.isDirectory) {
            val d = parent.findFile(src.name) ?: parent.createDirectory(src.name)
                ?: throw IOException("Création du dossier impossible : ${src.name}")
            src.listFiles()?.forEach { copyIntoDoc(ctx, it, d, t) }
        } else {
            val target = parent.createFile(mimeOf(src), src.name)
                ?: throw IOException("Création du fichier impossible : ${src.name}")
            try {
                val out = ctx.contentResolver.openOutputStream(target.uri)
                    ?: throw IOException("Écriture impossible : ${src.name}")
                out.use { o ->
                    src.inputStream().use { i ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            t.add(n.toLong(), src.name)
                        }
                    }
                }
            } catch (e: Exception) {
                target.delete()
                throw e
            }
        }
    }

    /** Copie vers un dossier choisi avec le Storage Access Framework (carte SD, clé USB, etc.). */
    fun runTree(
        ctx: Context, files: List<File>, tree: Uri, cut: Boolean,
        publish: (String, Long, Long) -> Unit, cancelled: () -> Boolean
    ): String? {
        val dest = DocumentFile.fromTreeUri(ctx, tree) ?: return "Dossier de destination invalide."
        if (!dest.canWrite()) return "Android n'autorise pas l'écriture dans ce dossier. Choisis-en un autre."
        for (f in files) {
            if (!f.exists()) return "« ${f.name} » n'existe plus."
            if (!FileRepo.isSafe(f)) return "Opération refusée sur « ${f.name} »."
        }
        val total = files.sumOf { sizeOf(it) }
        val t = Tracker(total, publish, cancelled)
        publish("", 0L, total)
        for (f in files) {
            try {
                copyIntoDoc(ctx, f, dest, t)
                if (cut && !FileRepo.delete(f)) return "Copié, mais l'original « ${f.name} » n'a pas pu être supprimé."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return friendly(e)
            }
        }
        return null
    }

    /** Export d'un APK installé (lecture seule de l'APK public, jamais des données privées). */
    fun runApk(src: File, dst: File, publish: (String, Long, Long) -> Unit, cancelled: () -> Boolean): String? {
        if (!src.canRead()) return "Android n'autorise pas l'export de cette application."
        val parent = dst.parentFile ?: return "Destination invalide."
        parent.mkdirs()
        val total = src.length()
        val free = try { StatFs(parent.path).availableBytes } catch (e: Exception) { Long.MAX_VALUE }
        if (total > free) return "Espace insuffisant : il manque ${FileRepo.humanSize(total - free)}."
        val t = Tracker(total, publish, cancelled)
        publish(src.name, 0L, total)
        return try {
            copyTree(src, dst, t)
            null
        } catch (e: CancellationException) {
            dst.delete()
            throw e
        } catch (e: Exception) {
            dst.delete()
            friendly(e)
        }
    }
}
